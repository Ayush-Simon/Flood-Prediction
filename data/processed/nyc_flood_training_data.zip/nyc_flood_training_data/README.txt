NYC Flood Watch - training data for the depth models (ANN-LSTM, CNN-LSTM, LSTM)
Made by scripts/07b_depth_5min.py from FloodNet NYC street flood sensors and NOAA airport rain gauges.

One row = one sensor, one 5-minute step, during a storm window (the hours around rain).
27 sensors, 6,809 storm windows, Oct 2020 - Oct 2026, 709,693 rows.

Files (split by time, exactly as the models were trained and tested)
  1_train_2020-2025.csv            440,605 rows  - the models learned from these
  2_validation_2026-Jan-Jun.csv    150,468 rows  - used to stop training at the best point
  3_test_2026-Jul-Oct.csv          118,620 rows  - never seen in training; all reported scores
  4_example_one_storm_for_Model_Lab.csv          - one test storm, ready to upload to the Model Lab

Columns
  Sensor ID             FloodNet sensor
  time_utc              start of the 5-minute step, UTC
  depth_in              water depth on the street, inches (0 = dry)            <- what the models predict
  rain_mm               rain in those 5 minutes at the nearest airport gauge, mm (empty = gauge missing)
  gauge                 which gauge: NYC = Central Park, LGA = LaGuardia, JFK = JFK
  gauge_km              distance from the sensor to that gauge, km
  elevation_m, slope_deg, height_above_low_in   terrain at the sensor (used only by the terrain experiments)
  storm_id              storm window id; windows never cross from one storm to the next

How the models use it
  Input  = the last 12 rows (1 hour) of depth_in, rain_mm and a rain-missing flag at one sensor
  Output = depth_in for the next 8 rows (5 to 40 minutes ahead)

Sources: FloodNet NYC (NYC Open Data, dataset aq7i-eu5q), NOAA ASOS 1-minute rain via Iowa Environmental Mesonet.
